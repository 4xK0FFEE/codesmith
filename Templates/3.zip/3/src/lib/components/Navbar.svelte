<script lang="ts">
  import { page } from '$app/stores';
  import type { Session } from '@supabase/supabase-js';

  export let session: Session | null;
</script>

<nav class="bg-white shadow-lg">
  <div class="max-w-7xl mx-auto px-4">
    <div class="flex justify-between h-16">
      <div class="flex">
        <a href="/" class="flex-shrink-0 flex items-center">
          <span class="text-xl font-bold">Your App</span>
        </a>
      </div>
      <div class="flex items-center">
        {#if session}
          <a
            href="/dashboard"
            class="text-gray-700 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium"
          >
            Dashboard
          </a>
          <form action="/auth/signout" method="POST">
            <button
              type="submit"
              class="text-gray-700 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium"
            >
              Sign out
            </button>
          </form>
        {:else}
          <a
            href="/auth/login"
            class="text-gray-700 hover:text-gray-900 px-3 py-2 rounded-md text-sm font-medium"
          >
            Login
          </a>
          <a
            href="/auth/register"
            class="ml-4 bg-blue-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-700"
          >
            Register
          </a>
        {/if}
      </div>
    </div>
  </div>
</nav>