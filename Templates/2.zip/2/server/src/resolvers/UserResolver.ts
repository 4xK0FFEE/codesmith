import { Resolver, Query, Mutation, Arg } from 'type-graphql';
import { User, UserModel } from '../models/User';
import { hash, compare } from 'bcryptjs';
import { sign } from 'jsonwebtoken';

@Resolver()
export class UserResolver {
  @Query(() => [User])
  async users(): Promise<User[]> {
    return await UserModel.find();
  }

  @Mutation(() => String)
  async register(
    @Arg('username') username: string,
    @Arg('email') email: string,
    @Arg('password') password: string
  ): Promise<string> {
    const hashedPassword = await hash(password, 12);
    
    const user = await UserModel.create({
      username,
      email,
      password: hashedPassword
    });

    return sign({ userId: user.id }, process.env.JWT_SECRET || 'secret');
  }

  @Mutation(() => String)
  async login(
    @Arg('email') email: string,
    @Arg('password') password: string
  ): Promise<string> {
    const user = await UserModel.findOne({ email });
    if (!user) {
      throw new Error('User not found');
    }

    const valid = await compare(password, user.password);
    if (!valid) {
      throw new Error('Invalid password');
    }

    return sign({ userId: user.id }, process.env.JWT_SECRET || 'secret');
  }
}