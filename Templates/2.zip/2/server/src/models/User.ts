import { Field, ObjectType } from 'type-graphql';
import { prop as Property } from '@typegoose/typegoose';
import { getModelForClass } from '@typegoose/typegoose';

@ObjectType()
export class User {
  @Field()
  @Property({ required: true })
  username: string;

  @Field()
  @Property({ required: true, unique: true })
  email: string;

  @Property({ required: true })
  password: string;

  @Field()
  @Property({ default: Date.now })
  createdAt: Date;
}

export const UserModel = getModelForClass(User);