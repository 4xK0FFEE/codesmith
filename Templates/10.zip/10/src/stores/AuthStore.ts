import { makeAutoObservable } from "mobx";
import { RootStore } from "./RootStore";
import auth from "@react-native-firebase/auth";

export class AuthStore {
	user: any = null;
	loading: boolean = false;
	rootStore: RootStore;

	constructor(rootStore: RootStore) {
		this.rootStore = rootStore;
		makeAutoObservable(this);

		auth().onAuthStateChanged((user) => {
			this.setUser(user);
		});
	}

	setUser(user: any) {
		this.user = user;
	}

	setLoading(state: boolean) {
		this.loading = state;
	}

	async signIn(email: string, password: string) {
		try {
			this.setLoading(true);
			const response = await auth().signInWithEmailAndPassword(email, password);
			return response;
		} catch (error) {
			throw error;
		} finally {
			this.setLoading(false);
		}
	}

	async signOut() {
		try {
			await auth().signOut();
		} catch (error) {
			throw error;
		}
	}
}
