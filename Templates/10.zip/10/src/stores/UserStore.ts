import { makeAutoObservable } from "mobx";
import { RootStore } from "./RootStore";
import firestore from "@react-native-firebase/firestore";

export class UserStore {
	userData: any = null;
	rootStore: RootStore;

	constructor(rootStore: RootStore) {
		this.rootStore = rootStore;
		makeAutoObservable(this);
	}

	setUserData(data: any) {
		this.userData = data;
	}

	async fetchUserData(userId: string) {
		try {
			const userDoc = await firestore().collection("users").doc(userId).get();

			if (userDoc.exists) {
				this.setUserData(userDoc.data());
			}
		} catch (error) {
			console.error("Error fetching user data:", error);
			throw error;
		}
	}
}
