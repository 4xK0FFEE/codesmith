import React from "react";
import { SafeAreaProvider } from "react-native-safe-area-context";
import AppNavigator from "./navigation/AppNavigator";
import { RootStoreProvider } from "../stores";

const App = () => {
	return (
		<RootStoreProvider>
			<SafeAreaProvider>
				<AppNavigator />
			</SafeAreaProvider>
		</RootStoreProvider>
	);
};

export default App;
