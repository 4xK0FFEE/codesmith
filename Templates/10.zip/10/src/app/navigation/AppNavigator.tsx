import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { observer } from "mobx-react-lite";
import { useStores } from "../../stores";

const Stack = createStackNavigator();

const AppNavigator = observer(() => {
	const { authStore } = useStores();

	return (
		<NavigationContainer>
			<Stack.Navigator>
				{!authStore.user ? (
					// Auth Stack
					<Stack.Group>
						<Stack.Screen name="Login" component={LoginScreen} />
						<Stack.Screen name="Register" component={RegisterScreen} />
					</Stack.Group>
				) : (
					// Main App Stack
					<Stack.Group>
						<Stack.Screen name="Home" component={HomeScreen} />
						<Stack.Screen name="Profile" component={ProfileScreen} />
					</Stack.Group>
				)}
			</Stack.Navigator>
		</NavigationContainer>
	);
});

export default AppNavigator;
