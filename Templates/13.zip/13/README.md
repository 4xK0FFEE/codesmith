# FastAPI + PyTorch + MLflow Project

This project implements an AI service using FastAPI for the backend, PyTorch for machine learning models, and MLflow for experiment tracking.

## Setup

1. Clone the repository:
```bash
git clone <repository-url>
cd fastapi-pytorch-mlflow
```

2. Create and activate virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -e .
```

## Running the Application

1. Start the FastAPI server:
```bash
python main.py
```

2. Access the API documentation at:
```
http://localhost:8000/docs
```

## MLflow Tracking

MLflow experiments are stored in the `mlruns` directory. To view the MLflow UI:
```bash
mlflow ui
```

Then visit `http://localhost:5000`

## Project Structure

- `app/`: Main application package
  - `api/`: API endpoints and routing
  - `core/`: Core configuration and settings
  - `models/`: PyTorch model definitions
  - `schemas/`: Pydantic models for request/response
  - `services/`: Business logic and ML services
- `configs/`: Configuration files
- `data/`: Data directory
- `tests/`: Test files
- `main.py`: Application entry point

## API Endpoints

- `POST /api/v1/predict`: Make predictions
- `POST /api/v1/train`: Train the model
- `POST /api/v1/upload-data`: Upload training data

## Testing

Run tests using:
```bash
pytest
```