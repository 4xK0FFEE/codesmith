from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_predict():
    response = client.post(
        "/api/v1/predict",
        json={"features": [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0]}
    )
    assert response.status_code == 200
    assert "prediction" in response.json()

def test_train():
    response = client.post("/api/v1/train")
    assert response.status_code == 200
    assert "message" in response.json()