from fastapi import APIRouter, UploadFile, File
from app.schemas.prediction import PredictionInput, PredictionOutput
from app.services.ml_service import MLService

router = APIRouter()
ml_service = MLService()

@router.post("/predict", response_model=PredictionOutput)
async def predict(input_data: PredictionInput):
    prediction = ml_service.predict(input_data)
    return PredictionOutput(prediction=prediction)

@router.post("/train")
async def train_model():
    ml_service.train()
    return {"message": "Training completed successfully"}

@router.post("/upload-data")
async def upload_data(file: UploadFile = File(...)):
    # Implementation for data upload
    return {"filename": file.filename}