import torch
import mlflow
import mlflow.pytorch
from app.models.model import SimpleNeuralNetwork

class ModelTrainer:
    def __init__(self, input_size, hidden_size, output_size):
        self.model = SimpleNeuralNetwork(input_size, hidden_size, output_size)
        self.criterion = torch.nn.MSELoss()
        self.optimizer = torch.optim.Adam(self.model.parameters())

    def train(self, train_loader, epochs):
        mlflow.set_tracking_uri("mlruns")
        with mlflow.start_run():
            mlflow.log_param("input_size", self.model.layer1.in_features)
            mlflow.log_param("hidden_size", self.model.layer1.out_features)
            
            for epoch in range(epochs):
                for batch_idx, (data, target) in enumerate(train_loader):
                    self.optimizer.zero_grad()
                    output = self.model(data)
                    loss = self.criterion(output, target)
                    loss.backward()
                    self.optimizer.step()
                
                mlflow.log_metric("loss", loss.item(), epoch)
            
            mlflow.pytorch.log_model(self.model, "model")