import torch
from app.models.model import SimpleNeuralNetwork
from app.models.training import ModelTrainer
import mlflow.pytorch

class MLService:
    def __init__(self):
        self.model = None
        self.load_model()

    def load_model(self):
        try:
            self.model = mlflow.pytorch.load_model("models/latest")
        except:
            # Initialize a new model if none exists
            self.model = SimpleNeuralNetwork(input_size=10, hidden_size=20, output_size=1)

    def predict(self, input_data):
        if self.model is None:
            self.load_model()
        
        # Convert input to tensor
        input_tensor = torch.FloatTensor(input_data.features)
        with torch.no_grad():
            prediction = self.model(input_tensor)
        return prediction.item()

    def train(self, train_data=None):
        trainer = ModelTrainer(input_size=10, hidden_size=20, output_size=1)
        # Implement training logic here
        pass