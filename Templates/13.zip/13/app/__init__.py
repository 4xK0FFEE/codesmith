from app.api.router import router
from app.core.config import settings