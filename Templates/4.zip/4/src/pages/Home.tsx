import { Counter } from '../features/counter/Counter'

const Home = () => {
  return (
    <div className="space-y-8">
      <h1 className="text-4xl font-bold">Welcome to React RTK</h1>
      <p className="text-lg text-gray-600">
        This is a starter template for React with Redux Toolkit and RTK Query
      </p>
      <Counter />
    </div>
  )
}

export default Home