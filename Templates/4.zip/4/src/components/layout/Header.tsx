import { Link } from 'react-router-dom'

const Header = () => {
  return (
    <header className="bg-white shadow">
      <nav className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center">
          <Link to="/" className="text-xl font-bold">
            React RTK
          </Link>
          <div className="flex gap-4">
            <Link to="/" className="hover:text-blue-500">
              Home
            </Link>
          </div>
        </div>
      </nav>
    </header>
  )
}

export default Header