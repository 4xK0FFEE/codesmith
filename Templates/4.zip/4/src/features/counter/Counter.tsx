import { useAppDispatch, useAppSelector } from '../../hooks'
import { decrement, increment, selectCount } from './counterSlice'

export function Counter() {
  const count = useAppSelector(selectCount)
  const dispatch = useAppDispatch()

  return (
    <div className="flex items-center gap-4">
      <button
        className="px-4 py-2 bg-blue-500 text-white rounded"
        onClick={() => dispatch(decrement())}
      >
        -
      </button>
      <span className="text-2xl">{count}</span>
      <button
        className="px-4 py-2 bg-blue-500 text-white rounded"
        onClick={() => dispatch(increment())}
      >
        +
      </button>
    </div>
  )
}